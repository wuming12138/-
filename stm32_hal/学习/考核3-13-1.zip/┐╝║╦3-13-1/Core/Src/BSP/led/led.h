#ifndef __LED_H
#define __LED_H

#include "main.h"
void LED_Init(void);
void LED_Disp(unsigned char ucLed);
void LED_DispOne_ON(unsigned char ucLed);
void LED_DispOne_OFF(unsigned char ucLed);

#endif


