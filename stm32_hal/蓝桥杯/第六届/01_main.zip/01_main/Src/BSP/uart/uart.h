#ifndef __USART_H__
#define __USART_H__


#include "main.h"


extern UART_HandleTypeDef huart1;


void UART_Init(void);


#endif
