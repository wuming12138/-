#include "main.h"


#ifndef __TIM6_H__
#define __TIM6_H__




#include "main.h"



extern TIM_HandleTypeDef htim6;

void TIM6_Init(void);


#endif

