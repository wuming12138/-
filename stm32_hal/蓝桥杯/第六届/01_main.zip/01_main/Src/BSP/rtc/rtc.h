#ifndef __RTC_H__
#define __RTC_H__


#include "main.h"


extern RTC_HandleTypeDef hrtc;


void RTC_Init(void);


#endif
