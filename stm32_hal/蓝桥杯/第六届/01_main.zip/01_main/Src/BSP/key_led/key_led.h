#ifndef __KEY_LED_H__
#define __KEY_LED_H__


#include "main.h"


void Key_Led_Init(void);
void LED_Disp(uint8_t wLED);
uint8_t Key_Scan(void);


#endif 
