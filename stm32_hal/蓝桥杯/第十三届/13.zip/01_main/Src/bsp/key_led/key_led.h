#ifndef __GPIO_H__
#define __GPIO_H__


#include "main.h"

void Key_Led_Init(void);
uint8_t Key_Scan(void);
void LED_Disp(uint8_t uwLED);


#endif

