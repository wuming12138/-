#ifndef __KEY_H
#define __KEY_H

#include "main.h"
void Key_Init(void);
unsigned char Key_Scan(void);

#endif

