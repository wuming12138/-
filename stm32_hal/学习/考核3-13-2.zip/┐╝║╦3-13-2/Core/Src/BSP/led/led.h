#ifndef __LED_H
#define __LED_H

#include "main.h"
void LED_Init(void);
void LED_Disp(unsigned char ucLed);

#endif


