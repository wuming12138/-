#ifndef __BUZ_H
#define __BUZ_H

#include "main.h"

void Buz_Init(void);

#endif

