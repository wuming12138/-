#ifndef __UART_H
#define __UART_H

#include "main.h"

/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

extern UART_HandleTypeDef huart1;

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

void USART1_Init(void);


/* USER CODE BEGIN Prototypes */

/* USER CODE END Prototypes */


#endif

